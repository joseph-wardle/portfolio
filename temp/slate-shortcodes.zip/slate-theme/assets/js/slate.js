document.querySelectorAll('.s-embed-frame[data-yt]').forEach(btn=>{
  btn.addEventListener('click',()=>{
    const id=btn.dataset.yt, st=btn.dataset.start?('&start='+btn.dataset.start):'';
    const f=document.createElement('iframe');
    f.src=`https://www.youtube-nocookie.com/embed/${id}?autoplay=1${st}`;
    f.allow='accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture';
    f.allowFullscreen=true; f.title='YouTube video';
    btn.replaceWith(f);
  });
});
document.querySelectorAll('[data-carousel]').forEach(c=>{
  const track=c.querySelector('.s-carousel-track');
  const dots=[...c.querySelectorAll('.s-carousel-dots span')];
  const slides=[...c.querySelectorAll('.s-slide')];
  c.querySelectorAll('.s-carousel-nav').forEach(b=>b.addEventListener('click',()=>{
    track.scrollBy({left:track.clientWidth*0.8*(+b.dataset.dir),behavior:'smooth'});
  }));
  track.addEventListener('scroll',()=>{
    const i=Math.round(track.scrollLeft/(slides[0].offsetWidth+14));
    dots.forEach((d,j)=>d.classList.toggle('on',j===i));
  },{passive:true});
});
document.querySelectorAll('[data-compare]').forEach(c=>{
  const pane=c.querySelector('.s-compare-pane');
  const range=c.querySelector('.s-compare-range');
  range.addEventListener('input',()=>pane.style.setProperty('--pos',range.value+'%'));
});
