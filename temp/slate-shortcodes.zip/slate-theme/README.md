# Slate shortcodes

Seven Hugo shortcodes in the slate style, for the new template system (Hugo ≥ 0.146).

## Install

Copy into your site (or theme) root:

```
layouts/_shortcodes/   github.html  youtube.html  video.html  carousel.html  compare.html  spec.html  callout.html
assets/css/            shortcodes.css
assets/js/             slate.js
```

Pipe the CSS and JS from your `_partials/head.html` (CSS) and before `</body>` (JS):

```go-html-template
{{ with resources.Get "css/shortcodes.css" | minify | fingerprint }}
  <link rel="stylesheet" href="{{ .RelPermalink }}" integrity="{{ .Data.Integrity }}">
{{ end }}
{{ with resources.Get "js/slate.js" | minify | fingerprint }}
  <script src="{{ .RelPermalink }}" integrity="{{ .Data.Integrity }}" defer></script>
{{ end }}
```

`shortcodes.css` starts with the slate `:root` tokens. If your main stylesheet already
defines them, delete that first block to avoid duplication.

## Usage

```
{{< github "joseph-wardle/javelin" >}}

{{< youtube id="dQw4w9WgXcQ" caption="Publish workflow, end to end" >}}

{{< video src="publish-demo.mp4" caption="One click, zero manual steps" >}}
{{< video src="loop.mp4" poster="poster.jpg" loop="true" >}}

{{< carousel "render-*" caption="Lookdev turntable frames" >}}

{{< compare before="raw.png" after="denoised.png" labels="Raw|Denoised" >}}

{{< spec >}}
Role: Sole pipeline TD
Team: 50+ artists
Stack: Python, USD, Houdini, ShotGrid
Status: In production
{{< /spec >}}

{{< callout type="tip" title="Why USD?" >}}
It's the one format every department already speaks.
{{< /callout >}}
```

## Notes

- **github** fetches live at build time via `resources.GetRemote` against the GitHub API
  (unauthenticated: 60 req/hr, cached between builds). The dot color comes from a small
  language map inside the shortcode — extend it as needed.
- **video**, **carousel**, **compare** read images/clips from the **page bundle** as
  resources, so the files live next to the page's `index.md` (e.g. `render-01.png`,
  `publish-demo.mp4`). Hugo processes/resizes them automatically.
- **youtube** renders a lightweight poster facade and only loads the iframe on click
  (privacy via `youtube-nocookie.com`, no third-party JS until the user opts in).
- **carousel** and **compare** need `slate.js`; everything else is pure CSS/HTML.
- All components respect `prefers-reduced-motion` via your site CSS.
